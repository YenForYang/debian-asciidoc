print("No barchart to avoid depending on Pychart for the tests.\n"
      "See also: http://asciidoc.org/faq.html#_is_it_possible_to_include_charts_in_asciidoc_documents")
